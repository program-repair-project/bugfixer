package org.apache.aries.jpa.blueprint.impl;

public interface TestInterface {

}
