pip install -r ./pyter_requirements.txt
pip install -e .